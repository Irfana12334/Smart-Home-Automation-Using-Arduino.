
# Smart Home Automation Using Arduino

This project allows users to control home appliances like fans and lights remotely using a mobile app (Blynk) and automates climate control based on room temperature via DHT11 sensor.

## Components Used
- Arduino UNO / ESP32
- DHT11 Sensor
- Relay Module
- Blynk App
- Wi-Fi / Bluetooth Module
- Home Appliances

## Features
- Remote control through Blynk App.
- Automatic Fan/AC control based on room temperature.
- Easy to install, cost-effective, and energy-efficient.

---
